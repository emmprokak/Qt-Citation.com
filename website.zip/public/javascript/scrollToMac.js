$(document).ready(function () {
    document.querySelector("#scrollToMac").scrollIntoView({ behavior: "smooth" })
});