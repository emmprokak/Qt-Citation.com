$(document).ready(function () {
    document.querySelector("#scrollToLinux").scrollIntoView({ behavior: "smooth" })
});